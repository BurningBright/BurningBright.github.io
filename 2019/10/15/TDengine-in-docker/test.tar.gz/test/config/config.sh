#!/bin/bash

# ==================Insert configurable parameters==================
export SCHEMA_FILE=${DATA_HOME}/schema.txt
export SAMPLE_FILE=${DATA_HOME}/sample.txt
export NDETECTORS=100000
export INSERT_THREAD=10
export RECORDS_PER_DETECTOR=10000
export START_TIME='01/01/2015 00:00:00'
# in milliseconds
export TIME_INTERVAL=900000

# ==================Query configurable parameters==================
export QUERY_TIME=1
export QUERY_THREAD=1
