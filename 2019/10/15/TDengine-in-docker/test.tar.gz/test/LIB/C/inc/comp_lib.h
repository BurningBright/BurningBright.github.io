#ifndef __COMP_LIB__
#define __COMP_LIB__

double get_curr_time_in_sec();
int regex_match(const char * s, const char * reg);

#endif 
